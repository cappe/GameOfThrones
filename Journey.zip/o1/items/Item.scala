package o1.items

class Item(val name: String, val description: String, var effectivity: Int) {

}